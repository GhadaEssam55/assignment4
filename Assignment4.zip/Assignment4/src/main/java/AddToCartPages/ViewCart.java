package AddToCartPages;

import Pages.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.awt.*;
import java.util.List;

public class ViewCart extends BasePageToCart {

    private  By allItemOnCart =By.xpath("//tr[contains(@id, 'product-')]");
    private By priceOFTop =By.xpath("//tr[@id=\"product-1\"]/td[@class=\"cart_price\"]");
    private By 	quantityOfTop =By.xpath("//tr[@id=\"product-1\"]/td[@class=\"cart_quantity\"]");
   private By totalPriceOfTop =By.xpath("//tr[@id=\"product-1\"]/td[@class=\"cart_total\"]");
    private By priceOFTShirt =By.xpath("//tr[@id=\"product-2\"]/td[@class=\"cart_price\"]");
    private By quantityOfTShirt =By.xpath("//tr[@id=\"product-2\"]/td[@class=\"cart_quantity\"]");
   private By totalPriceTShirt =By.xpath("//tr[@id=\"product-2\"]/td[@class=\"cart_total\"]");




public ViewCart(WebDriver driver) {
    super(driver);

    }
    public int CartContains(){
        List<WebElement> itemsOnCart = locateListElement(allItemOnCart);
       return itemsOnCart.size();


    }
    public String  price1Product(){
       return textElements(priceOFTop);

    }
    public String quantity1Product(){
       return textElements(quantityOfTop);

    }
    public String total1Product(){
       return textElements(totalPriceOfTop);

    }
    public String price2Product(){
       return textElements(priceOFTShirt);

    }
    public String quantity2Product(){

       return textElements(quantityOfTShirt);

    }
    public String total2Product(){

       return textElements(totalPriceTShirt);
    }

}
