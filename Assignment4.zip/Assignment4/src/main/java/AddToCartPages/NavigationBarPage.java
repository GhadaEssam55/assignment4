package AddToCartPages;

import Pages.SearchProductPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class NavigationBarPage extends BasePageToCart {
    private By featuredItem = By.xpath("//div[@class=\"features_items\"]/h2[contains(text(),'Features Items')]");
    private By productsBtn = By.xpath("//li/a[@href=\"/products\"]");


    public NavigationBarPage(WebDriver driver) {
        super(driver);

    }

    public String verifyHome() {

        return textElements(featuredItem);
    }

    public HoveringToFirstProd productButton() {
        clickElement(productsBtn);
        return new HoveringToFirstProd(driver);
    }

}
