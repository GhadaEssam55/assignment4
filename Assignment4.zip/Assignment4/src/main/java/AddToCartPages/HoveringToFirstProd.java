package AddToCartPages;

import Pages.BasePage;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class HoveringToFirstProd extends BasePageToCart {

    private   By firBlueTop =By.xpath("//div[@class=\"productinfo text-center\"]/img[@src=\"/get_product_picture/1\"]");
    private   By addToCartBtn =By.xpath("//div/a[@data-product-id=\"1\"]");
    private  By continueShopping =By.xpath("//button[@class=\"btn btn-success close-modal btn-block\"]");

    public HoveringToFirstProd(WebDriver driver) {
        super(driver);

    }

public void HoverOnFirstItem(){
   HoverOnItems(firBlueTop);
}
public void addOnCart(){
        forceClick(addToCartBtn);


}
public HoveringToSecProducts ShoppingComp(){
        clickElement(continueShopping);
        return new HoveringToSecProducts(driver);
}

}
