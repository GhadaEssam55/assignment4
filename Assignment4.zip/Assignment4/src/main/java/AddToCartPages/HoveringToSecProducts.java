package AddToCartPages;

import Pages.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class HoveringToSecProducts extends BasePageToCart {

    private  By secTShirt =By.xpath("//div[@class=\"productinfo text-center\"]/img[@src=\"/get_product_picture/2\"]");
    private  By clickAddCart =By.xpath("//div/a[@data-product-id=\"2\"]");
    private  By viewCart =By.xpath("//a[@href=\"/view_cart\"][1]");



    public HoveringToSecProducts(WebDriver driver) {
        super(driver);

    }
    public void HoverOnSecItem(){

        HoverOnItems(secTShirt);
}
public void addTShirt(){

   forceClick(clickAddCart);
    }
    public void clickToViewCart(){
      clickElement(viewCart);
      //return new ViewCart(driver);



    }
}
