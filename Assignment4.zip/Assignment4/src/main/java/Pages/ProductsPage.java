package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ProductsPage extends BasePage {
    private By productsBtn = By.xpath("//li/a[@href=\"/products\"]");
    private By allProducts =By.xpath("//div[@class=\"features_items\"]/h2[contains(text(),'All Products')]");

    public ProductsPage(WebDriver driver) {
       super(driver);

    }

    public SearchProductPage productButton(){
    clickElement(productsBtn);
        return new SearchProductPage(driver);
    }
    public String  verifyAllProducts(){
        return textElements(allProducts);

    }

}
