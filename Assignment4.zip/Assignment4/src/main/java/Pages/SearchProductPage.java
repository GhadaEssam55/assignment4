package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.awt.*;
import java.util.List;

public class SearchProductPage extends BasePage {

    private By searchField = By.name("search");
    private By sumSearchBtn = By.id("submit_search");
    private By verSearch = By.xpath("//div[@class=\"features_items\"]/h2[contains(text(),'Searched Products')]");
    private By visibleAllItems =By.xpath("//div[@class=\"product-overlay\"]");

    public SearchProductPage(WebDriver driver) {
        super(driver);

    }
    public void scrollToSearched(){
        scrollVertical(600);
    }

    public void searchToItem(String item) {
        typeOnInputField(searchField, item);
        clickElement(sumSearchBtn);

    }

    public String  verifySearch() {
        return  textElements(verSearch);



    }
    public int allItemsIsVisible(){
        List<WebElement> productsVisible = locateListElement(visibleAllItems);
        return productsVisible.size();
    }
}








