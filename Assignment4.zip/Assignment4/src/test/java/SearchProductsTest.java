
import Pages.*;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

public class SearchProductsTest extends BaseTest {

@Test
    public void SearchTest(){
   HomePage homePage =new HomePage(driver);

   Assert.assertEquals(homePage.verifyHome(), "FEATURES ITEMS",
            "The home page is not displayed");
    ProductsPage productsPage =new ProductsPage(driver);
   productsPage.productButton();
    SearchProductPage searchProductPage = new SearchProductPage(driver);
   searchProductPage.scrollToSearched();
    Assert.assertEquals(productsPage.verifyAllProducts(),"ALL PRODUCTS","It Should appear a ALL PRODUCTS");
   searchProductPage.searchToItem("Top");
   searchProductPage.scrollToSearched();
  Assert.assertEquals(searchProductPage.verifySearch(),"SEARCHED PRODUCTS");
   Assert.assertEquals(searchProductPage.allItemsIsVisible(),14,"Number of Items Is 14");

    }

    }


