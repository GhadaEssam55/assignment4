import AddToCartPages.HoveringToFirstProd;
import AddToCartPages.HoveringToSecProducts;
import AddToCartPages.NavigationBarPage;
import AddToCartPages.ViewCart;
import Pages.HomePage;
import Pages.ProductsPage;
import org.testng.Assert;
import org.testng.annotations.Test;


public class AddToCartTest extends BaseTest {
     @Test
     public void AddToCartTest() {
         NavigationBarPage navigationBarPage =new NavigationBarPage(driver);
         Assert.assertEquals(navigationBarPage.verifyHome(),"FEATURES ITEMS");
         HoveringToFirstProd hoveringToFirstProd =navigationBarPage.productButton();
         hoveringToFirstProd.HoverOnFirstItem();
         hoveringToFirstProd.addOnCart();
         hoveringToFirstProd.ShoppingComp();
         HoveringToSecProducts hoveringToSecProducts = new HoveringToSecProducts(driver);
         hoveringToSecProducts.HoverOnSecItem();
         hoveringToSecProducts.addTShirt();
         hoveringToSecProducts.clickToViewCart();
         ViewCart viewCart  =new ViewCart(driver);
          Assert.assertEquals(viewCart.CartContains(),2,"Number of Items Is 2");
          Assert.assertEquals(viewCart.price1Product(),"Rs. 500");
          Assert.assertEquals(viewCart.quantity1Product(),"1");
          Assert.assertEquals(viewCart.total1Product(),"Rs. 500");
          Assert.assertEquals(viewCart.price2Product(),"Rs. 400");
          Assert.assertEquals(viewCart.quantity2Product(),"1");
          Assert.assertEquals(viewCart.total2Product(),"Rs. 400");

     }
}


